package com.example.merchandisertracker

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.time.LocalTime
import java.util.concurrent.TimeUnit

class TrackingService : Service() {
    companion object {
        const val ACTION_START = "TRACK_START"
        const val ACTION_STOP = "TRACK_STOP"
        private const val CHANNEL = "gps_tracking"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var fused: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var active = false

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            ACTION_START -> startTracking()
        }
        return START_NOT_STICKY
    }

    private fun startTracking() {
        val user = auth.currentUser ?: run { stopSelf(); return }
        if (active) return

        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Work location tracking is ON")
            .setContentText("Your work location is being shared with your authorized administrator.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, TimeUnit.MINUTES.toMillis(2))
            .setMinUpdateIntervalMillis(TimeUnit.MINUTES.toMillis(1))
            .setWaitForAccurateLocation(false)
            .build()

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                val time = LocalTime.now()
                if (time.isBefore(LocalTime.of(7, 30)) || !time.isBefore(LocalTime.of(17, 0))) {
                    stopTracking()
                    return
                }
                val uid = user.uid
                val data = hashMapOf<String, Any>(
                    "uid" to uid,
                    "employeeId" to (user.email?.substringBefore("@") ?: "UNKNOWN"),
                    "latitude" to location.latitude,
                    "longitude" to location.longitude,
                    "accuracyMeters" to location.accuracy.toDouble(),
                    "serverTime" to FieldValue.serverTimestamp()
                )
                db.collection("liveLocations").document(uid).set(data)
                db.collection("locationHistory").document(uid).collection("points").add(data)
            }
        }
        try {
            fused.requestLocationUpdates(req, callback, mainLooper)
            active = true
            db.collection("workSessions").document(user.uid).set(
                mapOf("status" to "working", "startedAt" to FieldValue.serverTimestamp()),
                com.google.firebase.firestore.SetOptions.merge()
            )
        } catch (_: SecurityException) {
            stopTracking()
        }
    }

    private fun stopTracking() {
        if (active) {
            fused.removeLocationUpdates(callback)
            active = false
            auth.currentUser?.uid?.let { uid ->
                db.collection("workSessions").document(uid).set(
                    mapOf("status" to "stopped", "stoppedAt" to FieldValue.serverTimestamp()),
                    com.google.firebase.firestore.SetOptions.merge()
                )
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Work location tracking", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
