package com.example.merchandisertracker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Locale

class MainActivity : Activity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var status: TextView
    private lateinit var idInput: EditText
    private lateinit var passwordInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Firebase is initialized from the Android app's google-services.json.
        FirebaseApp.initializeApp(this)
        showLogin()
    }

    private fun showLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER
        }
        box.addView(TextView(this).apply { text = "MERCHANDISER GPS TRACKER"; textSize = 22f })
        idInput = EditText(this).apply { hint = "Employee ID (e.g. MER001)" }
        passwordInput = EditText(this).apply {
            hint = "Password"
            inputType = 129
        }
        box.addView(idInput)
        box.addView(passwordInput)
        val login = Button(this).apply { text = "LOGIN" }
        box.addView(login)
        status = TextView(this).apply { text = "Login with your assigned Employee ID." }
        box.addView(status)
        setContentView(box)
        login.setOnClickListener { login() }
    }

    private fun login() {
        val employeeId = idInput.text.toString().trim().uppercase(Locale.US)
        val password = passwordInput.text.toString()
        if (!employeeId.matches(Regex("[A-Z0-9_-]{3,24}")) || password.isBlank()) {
            status.text = "Enter a valid Employee ID and password."
            return
        }
        val emailAlias = "$employeeId@tracker.invalid"
        auth.signInWithEmailAndPassword(emailAlias, password)
            .addOnSuccessListener {
                db.collection("users").document(auth.currentUser!!.uid).get()
                    .addOnSuccessListener { doc ->
                        if (doc.getString("role") != "merchandiser") {
                            auth.signOut()
                            status.text = "This account is not a merchandiser account."
                        } else {
                            showWorkScreen(employeeId)
                        }
                    }
                    .addOnFailureListener { status.text = "Could not verify account: ${it.message}" }
            }
            .addOnFailureListener { status.text = "Login failed. Check Employee ID/password." }
    }

    private fun showWorkScreen(employeeId: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER
        }
        box.addView(TextView(this).apply { text = "Welcome $employeeId"; textSize = 22f })
        val start = Button(this).apply { text = "START WORK & LOCATION" }
        val stop = Button(this).apply { text = "STOP WORK" }
        status = TextView(this).apply { text = "Tracking only runs after you start work." }
        box.addView(start); box.addView(stop); box.addView(status)
        setContentView(box)

        start.setOnClickListener {
            val now = java.time.LocalTime.now()
            if (now.isBefore(java.time.LocalTime.of(7, 30)) || !now.isBefore(java.time.LocalTime.of(17, 0))) {
                status.text = "Start is allowed from 07:30 until 17:00."
                return@setOnClickListener
            }
            if (!hasLocationPermissions()) {
                requestLocationPermissions()
                return@setOnClickListener
            }
            val i = Intent(this, TrackingService::class.java)
            i.action = TrackingService.ACTION_START
            ContextCompat.startForegroundService(this, i)
            status.text = "Work started. Location tracking is active and visible in the notification."
        }
        stop.setOnClickListener {
            val i = Intent(this, TrackingService::class.java)
            i.action = TrackingService.ACTION_STOP
            startService(i)
            status.text = "Work stopped. Location tracking ended."
        }
    }

    private fun hasLocationPermissions(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val background = Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        return fine && background && notifications
    }

    private fun requestLocationPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 29) permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 700)
        status.text = "Allow location (including background) and notifications, then press START again."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 700) status.text = "If permissions were allowed, press START WORK again."
    }
}
