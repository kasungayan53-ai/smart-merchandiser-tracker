SMART MERCHANDISER GPS TRACKER - STARTER
========================================

මෙය මුල් Android + Admin Dashboard source project එකකි. APK එකක් නොවේ.
Android background GPS tracking සඳහා Android app එකේ foreground service සහ
දෘශ්‍යමාන ongoing notification එක භාවිතා කරයි. සේවකයාගේ පැහැදිලි දැනුවත්
කැමැත්ත සහ Location permission අනිවාර්යයි.

දැනට ඇතුළත්:
- Employee ID + password login (Firebase Auth email alias ක්‍රමය)
- START WORK / STOP WORK
- වැඩ ආරම්භය 07:30ට පසුව පමණක්; tracking 17:00ට නවතී
- විනාඩි 2කට වරක් GPS point එක Firestore වෙත යැවීම (foreground service)
- Admin web dashboard එකෙන් latest location සහ අද route එක Map එකක පෙන්වීම

වැදගත් සීමා:
- Android battery optimization, GPS/Internet නැතිවීම, force-stop, reboot සහ
  manufacturer-specific background restrictions නිසා 100% අඛණ්ඩ tracking
  සහතික කළ නොහැක.
- Offline points මෙම starter එකේ queue කර නැත; Internet නැති විට upload අසාර්ථක විය හැක.
- 17:00 stop එක service එක ධාවනය වෙමින් තිබේ නම් ක්‍රියාත්මක වේ. Force-stop කළහොත්
  Android විසින් service එක නවත්වයි.
- Firebase billing/usage quotas වෙනස් විය හැකිය. Firestore reads/writes usage
  වැඩිවුවහොත් ගාස්තු ඇති විය හැක. Billing plan එකට upgrade කිරීමට පෙර usage
  estimate කරගන්න.
- Dashboard map-ට OpenStreetMap tiles භාවිතා කරයි; Google Maps API key අවශ්‍ය නැත.
  OpenStreetMap tile usage policy අනුගමනය කරන්න.

මුලින් කළ යුතු දේ:
1) Firebase Console > Authentication > Sign-in method > Email/Password ON.
2) Android app එකට වෙනම Firebase Android app එක register කරන්න.
   Package name: com.example.merchandisertracker
   එයින් google-services.json ලබාගෙන android/app/ තුළ දමන්න.
3) Firebase Console > Authentication > Users:
   Admin account එක දැනට ඇති kasungayan53@gmail.com.
   Employee account එකක් සෑදීමේදී email ලෙස MER001@tracker.invalid යොදන්න.
   (Employeeට Gmail inbox එකක් අවශ්‍ය නැත; app-এ MER001 ID ලෙස type කර login થાય.)
4) Authentication Users list එකෙන් user UID copy කර Firestore `users/{UID}` document එකක්
   හදන්න. Admin document:
      role = "admin" (string)
      employeeId = "ADMIN" (string)
   Employee document:
      role = "merchandiser" (string)
      employeeId = "MER001" (string)
      displayName = "Merchandiser 1" (string)
   දැනට පැරණි `users/admin` document එක auth UID එක නොවේ; Rules සඳහා UID document එකක්
   අලුතින් හදන්න.
5) firebase/firestore.rules හි rules Firebase Console > Firestore > Rules වෙත publish කරන්න.
6) Dashboard: dashboard/index.html තුළ ඔබ ලබාදුන් Firebase Web config එක දැනටමත් ඇතුළත් කර ඇත.
7) Android: Android Studio වල android folder open කරලා google-services.json add කර Run කරන්න.
   APK build කිරීමට Android Studio/Gradle build අවශ්‍යයි.

Employee login:
- ID: MER001
- Password: Firebase Authentication user create කරන විට දුන් password එක.
- App එක ඇතුළත ID එක MER001@tracker.invalid ලෙස map කරයි.
- Password එක කිසිවිටෙක Dashboard/Firestore document එකක plaintext ලෙස තබන්න එපා.

Firestore collections:
- users/{authUid}
- liveLocations/{authUid}
- locationHistory/{authUid}/points/{autoId}

මෙය starter code එකකි; සැබෑ සේවා භාවිතයට පෙර Android device කිහිපයක test කර,
security rules, privacy notice, battery behaviour සහ billing limits පරීක්ෂා කරන්න.
